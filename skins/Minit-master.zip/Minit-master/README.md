Minit
=====
A minimalistic MediaWiki skin.

Originally developed for a personal wiki written in Korean.

![snapshot english](https://github.com/seongjaelee/Minit/raw/master/img/snapshot_english.png)
![snapshot korean](https://github.com/seongjaelee/Minit/raw/master/img/snapshot_korean.png)

Issues, questions and updates will be managed through the following site:
* https://github.com/seongjaelee/Minit

Minit does not support IE at all.

Minit is released under the terms of the GPL 2.0 or later. See LICENSE.
