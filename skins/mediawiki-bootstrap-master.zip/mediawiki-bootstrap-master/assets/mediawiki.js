// required jQuery version for Bootstrap should be pre-loaded into ResourceLoader
jqBootstrap = jQuery;
jQuery.noConflict(true);

