<?php
/**
 * Internationalisation file for skin AniMonaco.
 *
 * @file
 * @ingroup Extensions
 */

$messages = array();

/** English
 * @author Daniel Friesen
 */
$messages['en'] = array(
	'animonaco-desc' => "A Monaco subtheme, geared towards animanga wiki.",
);
