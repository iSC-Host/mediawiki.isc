<?php
/**
 * Internationalisation file for ContentRightSidebar extension.
 *
 * @file
 * @ingroup Extensions
 */

$messages = array();

/** English
 * @author Daniel Friesen
 */
$messages['en'] = array(
	'contentrightsidebar-desc' => "Adds parser tags with the ability to add right sidebar content to monaco skins.",
);
